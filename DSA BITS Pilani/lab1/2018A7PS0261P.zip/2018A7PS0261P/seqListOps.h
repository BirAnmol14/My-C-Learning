/***********file:   seqListOps.h *********/
#include "storage.h"

extern int inputJobs(JobList list);
extern void sortJobList(JobList list, int size);
extern void printJobList(JobList list, int size );
