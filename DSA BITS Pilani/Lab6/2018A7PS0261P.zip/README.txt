README LAB6
---------------------------------------
exer1.c -> solution to exercise1(merge operation)
---------------------------------------
ms_sort_rec.c -> recursive merge sort 
ms_sort_iter.c -> iterative merge sort
---------------------------------------
To compile:
make compRecMS -> recursive
make compIterMS -> iterative
---------------------------------------
To RUN:
make runRecMS or ./exe_ms_rec -> recursive
make runIterMS or ./exe_ms_iter -> iterative
---------------------------------------
OUTPUT:
in file output_ms_rec.txt -> recursive
in file output_ms_iter.txt -> iterative