Readme for LAB 3
The desired output is in output.exe (windows) or output (Ubuntu).
To run write ./output.out on Ubuntu machine and output on cmd on Windows.

The que_test_out file is just for checking if all queue functions are working correctly.Run it by saying ./que_test_out.out on linux or que_test_out on cmd in windows.

prof_output has gprof time values of each function