typedef struct rec{
	char name[11];
	int empID;
}rec;
