#include "exer1.h"
void insertInOrder(cc *,int);
void insertionSort(cc *,int);
extern unsigned long *base_add;
