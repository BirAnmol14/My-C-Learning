extern int heap_mem_allocated;
void * myalloc(int amount,int size);
void myfree(void * ptr,int amount, int size);
