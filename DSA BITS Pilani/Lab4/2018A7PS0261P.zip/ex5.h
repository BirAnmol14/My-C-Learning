#include "cycle.h"
#include "ex2.h"
Ls makeCircularList(Ls list);
