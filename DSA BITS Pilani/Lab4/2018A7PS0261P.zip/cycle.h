#include "ex3.h"
int testCyclic(Ls list);
