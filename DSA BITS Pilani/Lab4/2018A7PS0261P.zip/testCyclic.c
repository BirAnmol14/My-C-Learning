#include "cycle.h"
int testCyclic(Ls list){
	return 1;
}
